Add a batch file here in the Nuketo_files folder then rename that batch file to "extranukapp02.bat" for the os to detect and run the file

if it has a folder with other batch scripts that make the batch script you want to run on the os you can copy that to