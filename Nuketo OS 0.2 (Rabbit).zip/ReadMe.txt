Sorry if this may sound bad but i cant sign exes cuz i tried but nothing worked 
so if virustotal says its a vrius (even if its not)
then ignore it because THIS PROJECT IS NOT A VIRUS

i put the source code into virustotal and it said that it is safe 
but when i converted the source code into exe
virustotal says that it is a virus

here is proof that the source code is safe:
https://www.virustotal.com/gui/file/de62da53f1ae7bfb125dac9e82d76f10ffbfa62df64cfc76c7b8e50f87eb16ba/detection